package com.intel.samples.historicalcontext.online;

public class Settings {
    public static final String API_KEY      = "REPLACE WITH YOUR APIKEY";
    public static final String SECRET       = "REPLACE WITH YOUR SECRET";
    public static final String REDIRECT_URI = "REPLACE WITH REDIRECT URI";
}
