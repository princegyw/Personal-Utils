package com.intel.samples.contextsensingapiflow;

public class Settings {
    public static final String API_KEY      = "q4nu7w2d2kaqhs6vb8vsg79w";
    public static final String SECRET       = "hgs5UKCTJ7";
    public static final String REDIRECT_URI = "http://54.245.105.150/oauth2callback2.html";
}